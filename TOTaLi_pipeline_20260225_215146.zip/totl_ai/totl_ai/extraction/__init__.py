from totl_ai.extraction.extractor import DeterministicExtractor

__all__ = ["DeterministicExtractor"]
